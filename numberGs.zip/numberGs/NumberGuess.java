
import java.util.Random;
import java.util.Scanner;

class Game{
    int num;
    public Game(){
        Random first = new Random();
        num = first.nextInt(100);
        System.out.println("Guess the Number Form  1 to 100");
    }
    public int computerNo(){
        return num;
    }
}
public class NumberGuess{
    static int takeUserInput(){
        int user;
        System.out.println("Enter ");
        Scanner sc= new Scanner(System.in);
        user=sc.nextInt();
        return user;
    }

    static void isCorrectNumber(int i, int j){
        if(i==j){
            System.out.println("Correct NO. Guess");
        }
        else if(i>j){
            System.out.println("Your No. is too high than computer No.");
        }
        else {
            System.out.println("Your No. is too low than computer No.");
        }
    }
    public static void main(String[] args) {
        int user=0,computer=0,iterate=0;
        Game g = new Game();
        do {
            user = takeUserInput();
            computer = g.computerNo();

            isCorrectNumber(user, computer);
            iterate++;
        }while (user!=computer);
        System.out.println("YOU GUESS NO IN "+ iterate+" ITTERATIONS");


    }
}

